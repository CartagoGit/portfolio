---
name: delendai-proposals-workflow-playbook
appliesTo: ['@delendai/proposals']
description: Canonical compact workflow for agents working through the proposals plugin: orient, select work, claim files, implement, validate, close, and sync without polling or hand-editing generated state.
tools: ['delendai_proposals_continue_proposal', 'delendai_proposals_create_proposal', 'delendai_proposals_proposal_transition', 'delendai_proposals_close_slice', 'delendai_proposals_proposal_review', 'delendai_proposals_review_queue', 'delendai_proposals_review_claim', 'delendai_proposals_proposal_get']
---

# proposals workflow playbook

Use this when a session needs to advance proposal work through MCP tools.
It is the compact entrypoint; `delendai-proposal-swarm-runner` has the longer
background.

## Decision Tree

```
delendai_overview { compact: true }
  -> delendai_proposals_auto_work {}
  -> delendai_proposals_continue_proposal { id, mode: "plan" }
  -> delendai_proposals_delegate { taskId, slot, files }    # when the slice is non-trivial
     (delegate assigns a name, claims the lock, and — when the host
      gate `agentWorktree: true` is on — creates the per-agent worktree
      + branch `agent/<assigned-name>` atomically; x00051)
  -> edit only the claimed files (inside the worktree path when present)
  -> run the slice gate, usually bun run validate
  -> delendai_proposals_close_slice { id, sliceId }
  -> delendai_proposals_sync_proposals after the final slice/status move
```

The canonical path to spawn a subagent with isolation is
`auto_work → delegate`. Manual `delendai_proposals_agent_worktree` is reserved for the
rare case where the orchestrator wants a sidecar worktree without delegating
(e.g. read-mostly investigation). You should **not** call `agent_worktree
create` yourself before `delegate` — `delegate` does it for you when the
host gate is enabled.

> **Where the registry index lives (x00052).** The proposals
> registry index is a regenerable cache artefact, not a
> human-edited source file. Since x00052 it lives at
> `<cacheDir>/proposals/index.json` (default
> `.cache/delendai/proposals/index.json`), not under
> `docs/delendai/proposals/`. When an agent debugs "why is my
> proposal not appearing in the cascade", the answer is
> `proposals_sync_proposals` regenerates the index — it lives in
> the cache root, which is gitignored.

## Authoring a new proposal

A proposal that does not exist yet has no id to work on, so it is written
through the tool that allocates one, never as a file by hand:

```
# where the project works in units (`delendai work enter` is available):
delendai work enter --kind=create --proposal=new --slice=all --agent=<you> --topic=<t> --print-path
  -> delendai_proposals_create_proposal { title, goal, why, nonGoals, slices, checkout: <that worktree> }
  -> commit in the worktree, then publish the unit
```

- `create_proposal` allocates the id; a hand-picked id is not the
  contract and collides with ids other agents are allocating.
- The unit branch is renamed from `…/new-all-g1/…` to the real id in the
  same worktree and the same commit; publish it under that id.
- The contract has `goal`, `why`, `nonGoals`, `globalGate` and `slices`,
  and no `body`: a prose body is not written. An `unfilled-scaffold` lint
  finding means the content did not reach the file.
- If `create_proposal` is hidden (`active: false`), call
  `delendai_plugin_activate` for `proposals` and refresh tools/list, or
  reach it through the compact router; the search entry's `nextStep`
  says the same.
- Already wrote proposal files by hand? Keep the text, enter a create
  unit, re-author it there through `create_proposal` and let it allocate
  the ids; then remove the hand-written copies from the shared checkout.

## Persist Modes

`auto_work` can plan persistence, but the default is still manual review:

First, read `delendai.config.json#agentWorktree` (or the `--agent-worktree`
CLI flag). If `false`/unset — do not call `proposals_agent_worktree`; commit
to the active branch instead. The `agent_worktree` path below applies only
when the host has enabled the capability.

- `none`: default for CI, audits, and any shared worktree. The plan does
  **not** include a worktree step — nothing is being pushed.
- `commit`: local single-agent work after a focused diff review. When
  `agentWorktree: true`, `delegate` already created the worktree; the
  plan still surfaces an explicit `agent_worktree create` step as a
  safety net for solo runs.
- `commit-and-push`: only inside a disposable `agent_worktree` (requires the
  host gate enabled). The plan prepends the `agent_worktree create` step
  and the persist step pushes to `origin agent/<branch>` — the branch
  the worktree owns.

Do not infer a commit mode from enthusiasm. Pick the cheapest mode that
preserves ownership.

## Waiting

Do not poll lock status in a loop. If a claim fails because another agent
owns the files, wait for `notification_await_lock` or the
`lock-released` notification, then retry once with the same file scope.

## Never Do

1. Do not loop on `agent_lock status`.
2. Do not push from a shared checkout without `agent_worktree` (when the host
   has enabled it; if `agentWorktree` is `false`/unset, commit to the active
   branch instead — the tool is disabled by host configuration).
3. Do not edit `<cacheDir>/proposals/index.json` by hand (x00052 —
   used to be `docs/delendai/proposals/index.json`; moved to the
   cache root because it is a regenerable cache artefact, not a
   source file).
4. Do not run `delendai_proposals_sync_proposals` as a substitute for closing the
   current slice or moving the proposal file.
5. Do not write a proposal file by hand, or pick its id yourself: author it
   with `create_proposal` (see "Authoring a new proposal").
6. Do not treat a hidden tool as missing: activate its plugin, or use the
   compact router, instead of doing its work with file writes.

## Smoke

`delendai_knowledge` with no `id` should list entries, and
`delendai_proposals_auto_work` should either return a claimable slice/proposal or
an explicit idle reason. A silent empty response is a host assembly bug,
not a valid workflow state.

## Plans (q00001)

A `type: plan` proposal (prefix `q`) is an **orchestrator container** that
groups other proposals and/or carries its own executable slices. A plan
cannot close (`status: done`) until every contained proposal, sub-plan
and own slice is `done` + peer-reviewed.

### Working with a plan

1. Use `delendai_proposals_continue_proposal { planId: "q00001", mode: "plan" }`
   to inspect its `## Slices` section and the `contains:` block.
2. For each contained proposal, claim + close its slices as usual.
3. For own slices, claim them via `agent_lock` like any other slice.
4. When every child is done, call
   `delendai_proposals_close_plan { planId: "q00001", reason: "..." }`. The tool
   runs the closure preflight; if any child is still open, it returns a
   list of `blockers[]` you must resolve first.
5. `delendai_proposals_proposal_transition { id: "q00001", to: "done" }` also
   enforces the same rule (defence in depth) — both surfaces share the
   `evaluatePlanClosure` engine so they can never disagree.

### Sub-plans

A plan's `contains.plans[]` may reference other plans. The closure
evaluator recurses with cycle detection — a self-reference
(`q00001 → q00002 → q00001`) surfaces a `self-cycle` blocker instead of
infinite-looping.

### Minimal template

```yaml
---
id: q00042
type: plan
status: ready
track: my-area
contains:
    proposals:
        - { id: f00100, required: true }
        - { id: f00101, required: true }
    slices:
        - { id: qs1, title: "Build the dashboard" }
closureGate:
    requirePeerReview: true
    requireAllSlicesDone: true
    requireAllChildrenDone: true
globalGate: type
---

# q00042 — My orchestration plan

## goal

Ship f00100 and f00101 atomically as a single plan, with one extra
dashboard slice on top.

## Slices

### qs1 — Build the dashboard
- files: [apps/web/src/pages/plans/q00042.astro]
- gate: type
- status: pending
```
